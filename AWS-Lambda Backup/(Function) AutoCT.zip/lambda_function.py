import cv2
import sys
import json
import math
import base64
import random
import numpy as np
from scipy import ndimage


def lambda_handler(event, context):
	
	try:
		dataReceived = base64.b64decode(event["content"])
		dataReceived = json.loads(dataReceived)
		imageBase64 = base64.b64decode(dataReceived['image'])
		
		responseAlternatives, imagesRA, imagesOthers = resolveTemplate(from_base64(imageBase64))
		return makeResponse(responseAlternatives, imagesRA, imagesOthers)
	
	except:
		return makeResponseFail()
		

def makeResponse(responseAlternatives, imagesRA, imagesOthers):
    
	responseObject = {}
	responseObject['statusCode'] = 200
	responseObject['headers'] = {}
	responseObject['headers']['Content-Type'] = 'application/json'
	responseObject['body'] = {}
	responseObject['body']['alternatives'] = responseAlternatives
	responseObject['body']['imagensRA'] = imagesRA
	responseObject['body']['imagensOthers'] = imagesOthers
	
	return responseObject
	

def makeResponseFail():
	
	responseObject = {}
	responseObject['statusCode'] = 400
	responseObject['headers'] = {}
	responseObject['headers']['Content-Type'] = 'application/json'
	responseObject['body'] = 'Fail'
	
	return responseObject


def resolveTemplate(image):
	
	coordinatesJson = getCoordinates()
	bigRect = getBigRect(image)
	
	responseAlternatives = resolveAlternatives(coordinatesJson, bigRect)
	imagesRA = resolveRA(coordinatesJson, bigRect)
	imagesOthers = resolveOthers(coordinatesJson, bigRect)
	
	return responseAlternatives, imagesRA, imagesOthers


def resolveOthers(coordinatesJson, image):
	
	listImagesOthers = {}
	listImages = {}

	#dimensions of OthersAnswers square
	height = 29
	width = 25
	
	equalOne = 1
	column = 1
	line = 1
	
	#Get OthersAnswers keys from JSON
	others = list(coordinatesJson['Others'].keys())
	
	for question in others:
		for square in coordinatesJson['Others'][question]:
			x = coordinatesJson['Others'][question][square][0]
			y = coordinatesJson['Others'][question][square][1]
			
			#crop image
			croppedSquare = cropImage(x, y, width, height, image)
			imageOther = processCropped(imageNumber = croppedSquare)
			
			#opencv to base64
			_, image_arr = cv2.imencode('.png', imageOther)
			image_bytes = image_arr.tobytes()
			image_b64 = base64.b64encode(image_bytes)
			
			listImagesOthers[column] = str(image_b64)[2:-1]
			column = column + 1
			
		listImages[line] = listImagesOthers
		listImagesOthers = {}
		line = line + 1
		column = equalOne
			
	return listImages


def resolveRA(coordinatesJson, image):
	
	listImagesRA = {}

	#dimensions of RA square
	height = 29
	width = 25
	
	column = 1
	
	for square in coordinatesJson['RA']:
		x = coordinatesJson['RA'][square][0]
		y = coordinatesJson['RA'][square][1]
		
		#crop image
		croppedSquare = cropImage(x, y, width, height, image)
		imageRA = processCropped(imageNumber = croppedSquare)
		
		#opencv to base64
		_, image_arr = cv2.imencode('.png', imageRA)
		image_bytes = image_arr.tobytes()
		image_b64 = base64.b64encode(image_bytes)
		
		listImagesRA[column] = str(image_b64)[2:-1]
		column = column + 1
		
	return listImagesRA


def processCropped(imageNumber):

	
	imageGray = cv2.cvtColor(imageNumber, cv2.COLOR_RGB2GRAY)
	imageProcessed = processNumber(imageGray)
	return imageProcessed


def resolveAlternatives(coordinatesJson, image):
	
	responseAlternatives = {}
	
	#dimensions of Alternatives square
	height = 9
	width = 30
	
	listFiveRect = []
	
	#Get Alternatives keys from JSON
	alternatives = list(coordinatesJson['Alternatives'].keys())
	
	for question in alternatives:
		for square in coordinatesJson['Alternatives'][question]:
			x = coordinatesJson['Alternatives'][question][square][0]
			y = coordinatesJson['Alternatives'][question][square][1]
			
			croppedRect = cropImage(x, y, width, height, image)
			
			listFiveRect.append(croppedRect)
			
			if len(listFiveRect) == 5:
				question, answers = resolveAnternative(question, listFiveRect)
				
				#add in dict question and answers
				responseAlternatives[question] = answers
				
				listFiveRect = []
	    
	return responseAlternatives


def resolveAnternative(question, listFiveRect):

    answers = { 0 : "A", 1 : "B", 2 : "C", 3 : "D", 4 : "E" }
    listAverages = []

    for rect in listFiveRect:
        #obtain average of each alternative of the question
		
        average = np.average(rect)
        listAverages.append(average)

    #get position for minimal average (marked question has the lowest average)
    answerMarked = listAverages.index(min(listAverages))
    
    return question, answers[answerMarked]


def getCoordinates():
	
	with open('coordinates.json') as fileJson:
		coordinatesJson = json.load(fileJson)
		
		return coordinatesJson
	

def from_base64(base64_data):
    nparr = np.fromstring(base64_data, np.uint8)
    return cv2.imdecode(nparr, cv2.IMREAD_ANYCOLOR)
    

def getBestShift(img):
    cy,cx = ndimage.measurements.center_of_mass(img)

    rows,cols = img.shape
    shiftx = np.round(cols/2.0-cx).astype(int)
    shifty = np.round(rows/2.0-cy).astype(int)

    return shiftx,shifty


def shift(img,sx,sy):
    rows,cols = img.shape
    M = np.float32([[1,0,sx],[0,1,sy]])
    shifted = cv2.warpAffine(img,M,(cols,rows))
    return shifted


def processNumber(image):

    gray = cv2.resize(255-image, (28, 28))
    # better black and white version
    (thresh, gray) = cv2.threshold(gray, 128, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)

    while np.sum(gray[0]) == 0:
        gray = gray[1:]

    while np.sum(gray[:,0]) == 0:
        gray = np.delete(gray,0,1)

    while np.sum(gray[-1]) == 0:
        gray = gray[:-1]

    while np.sum(gray[:,-1]) == 0:
        gray = np.delete(gray,-1,1)

    rows,cols = gray.shape

    if rows > cols:
        factor = 20.0/rows
        rows = 20
        cols = int(round(cols*factor))
        # first cols than rows
        gray = cv2.resize(gray, (cols,rows))
        
    else:
        factor = 20.0/cols
        cols = 20
        rows = int(round(rows*factor))
        # first cols than rows
        gray = cv2.resize(gray, (cols, rows))

    colsPadding = (int(math.ceil((28-cols)/2.0)),int(math.floor((28-cols)/2.0)))
    rowsPadding = (int(math.ceil((28-rows)/2.0)),int(math.floor((28-rows)/2.0)))
    gray = np.lib.pad(gray,(rowsPadding,colsPadding),'constant')

    shiftx,shifty = getBestShift(gray)
    shifted = shift(gray,shiftx,shifty)
    gray = shifted

    return gray
    

def reshape(image):

    image = image.reshape(28, 28, -1)
    image = image.reshape(1, 28, 28, 1).astype('float32')
    image = image/255.0

    return image
    
    
def findContours(image):

    img_gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
    contours, hierarchy = cv2.findContours(~img_gray, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    
    return contours


def getBigRect(imageLoad):

    contours = findContours(imageLoad)
    templateRectangle = max(contours, key = cv2.contourArea)

    ## Stract the polygon points
    epsilonCurve = 0.01 * cv2.arcLength(templateRectangle, True)
    polygonExternalPoints = cv2.approxPolyDP(templateRectangle, epsilonCurve, True)

    x,y,w,h = cv2.boundingRect(polygonExternalPoints)
    bigRect = imageLoad[y:y+h, x:x+w]
    bigRect = cv2.resize(bigRect, (800, 1000))

    return bigRect


def cropImage(x, y, width, height, image):

    croppedImage = image[y:y + height, x:x + width]
    return croppedImage