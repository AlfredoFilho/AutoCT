import cv2
import json
# import boto3
import base64
import random
import numpy as np
import image as processimage
import number as processnumber


def lambda_handler(event, context):
	
	responseAlternatives, imagesRA, imagesOthers = resolveTemplate(from_base64(base64.b64decode(event["content"])))
	return makeResponse(responseAlternatives, imagesRA, imagesOthers)


def resolveTemplate(image):
	
	coordinatesJson = getCoordinates()
	bigRect = processimage.getBigRect(image)
	
	responseAlternatives = resolveAlternatives(coordinatesJson, bigRect)
	imagesRA = resolveRA(coordinatesJson, bigRect)
	imagesOthers = resolveOthers(coordinatesJson, bigRect)
	
	return responseAlternatives, imagesRA, imagesOthers


def resolveOthers(coordinatesJson, image):
	
	listImagesOthers = {}
	listImages = {}

	#dimensions of OthersAnswers square
	height = 29
	width = 25
	
	a = 1
	cont = 1
	aux = 1
	
	#Get OthersAnswers keys from JSON
	others = list(coordinatesJson['Others'].keys())
	
	for question in others:
		for square in coordinatesJson['Others'][question]:
			x = coordinatesJson['Others'][question][square][0]
			y = coordinatesJson['Others'][question][square][1]
			
			#crop image
			croppedSquare = processimage.cropImage(x, y, width, height, image)
			imgRA = processCropped(imageNumber = croppedSquare)
			
			listImagesOthers[cont] = imgRA.tolist()
			cont = cont + 1
			
		listImages[aux] = listImagesOthers
		aux = aux + 1
		cont = a
		listImagesOthers = {}
			
	return listImages


def resolveRA(coordinatesJson, image):
	
	listImagesRA = {}

	#dimensions of RA square
	height = 29
	width = 25
	
	cont = 1
	
	for square in coordinatesJson['RA']:
		x = coordinatesJson['RA'][square][0]
		y = coordinatesJson['RA'][square][1]
		
		#crop image
		croppedSquare = processimage.cropImage(x, y, width, height, image)
		imgRA = processCropped(imageNumber = croppedSquare)
		
		listImagesRA[cont] = imgRA.tolist()
		cont = cont + 1
		
	return listImagesRA


def processCropped(imageNumber):

	global listSixPredictions
	
	imageGray = cv2.cvtColor(imageNumber, cv2.COLOR_RGB2GRAY)
	imageProcessed = processnumber.processNumber(imageGray)
	
	return imageProcessed


def resolveAlternatives(coordinatesJson, image):
	
	responseAlternatives = {}
	
	#dimensions of Alternatives square
	height = 9
	width = 30
	
	listFiveRect = []
	
	#Get Alternatives keys from JSON
	alternatives = list(coordinatesJson['Alternatives'].keys())
	
	for question in alternatives:
		for square in coordinatesJson['Alternatives'][question]:
			x = coordinatesJson['Alternatives'][question][square][0]
			y = coordinatesJson['Alternatives'][question][square][1]
			
			croppedRect = processimage.cropImage(x, y, width, height, image)
			
			listFiveRect.append(croppedRect)
			
			if len(listFiveRect) == 5:
				question, answers = resolveAnternative(question, listFiveRect)
				
				#add in dict question and answers
				responseAlternatives[question] = answers
				
				listFiveRect = []
	    
	
	return responseAlternatives


def resolveAnternative(question, listFiveRect):

    answers = { 0 : "A", 1 : "B", 2 : "C", 3 : "D", 4 : "E" }
    listAverages = []

    for rect in listFiveRect:
        #obtain average of each alternative of the question
		
        average = np.average(rect)
        listAverages.append(average)

    #get position for minimal average (marked question has the lowest average)
    answerMarked = listAverages.index(min(listAverages))
    
    return question, answers[answerMarked]


def getCoordinates():
	
	with open('coordinates.json') as fileJson:
		coordinatesJson = json.load(fileJson)
		
		return coordinatesJson
	

def from_base64(base64_data):
    nparr = np.fromstring(base64_data, np.uint8)
    return cv2.imdecode(nparr, cv2.IMREAD_ANYCOLOR)
    

def makeResponse(responseAlternatives, imagesRA, imagesOthers):
    
	responseObject = {}
	responseObject['statusCode'] = 200
	responseObject['headers'] = {}
	responseObject['headers']['Content-Type'] = 'application/json'
	responseObject['body'] = {}
	responseObject['body']['alternativas'] = responseAlternatives
	responseObject['body']['imagensRA'] = imagesRA
	responseObject['body']['imagensOutras'] = imagesOthers
	
	return responseObject